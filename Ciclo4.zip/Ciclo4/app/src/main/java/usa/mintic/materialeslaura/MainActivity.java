package usa.mintic.materialeslaura;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnProducto, btnServicio, btnSucursales;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //aqui se llama las acciones de los productos
        btnProducto = findViewById(R.id.btnProductos);
        btnServicio = findViewById(R.id.btnServicios);
        btnSucursales = findViewById(R.id.btnSucursales);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.ic_index);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.productos) {
            Toast.makeText(this, "Se abrira la actividad de productos", Toast.LENGTH_LONG).show();
        }
        if (id == R.id.servicios) {
            Toast.makeText(this, "Se abrira la actividad de servicios", Toast.LENGTH_LONG).show();
        }
        if (id == R.id.sucursales) {
            Toast.makeText(this, "Se abrira la actividad de sucursales", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }


    public void Productos(View view) {
        Toast.makeText(this, "Se abrira la actividad productos", Toast.LENGTH_LONG).show();
    }

    public void Servicios(View view) {
        Toast.makeText(this, "Se abrira la actividad servicios", Toast.LENGTH_LONG).show();
    }

    public void Sucursales(View view) {
        Toast.makeText(this, "Se abrira la actividad sucursales", Toast.LENGTH_LONG).show();
    }
}